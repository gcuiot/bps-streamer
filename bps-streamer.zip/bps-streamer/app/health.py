"""Docker HEALTHCHECK: healthy if the streamer's heartbeat is under 15 minutes old."""
import os
import sys
import time

path = os.path.join(os.environ.get("WORK_DIR", "/tmp/bps"), "heartbeat")
try:
    age = time.time() - float(open(path).read())
except (OSError, ValueError):
    sys.exit(1)
sys.exit(0 if age < 900 else 1)
