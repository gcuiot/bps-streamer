"""docker exec bps check  ->  is this building working? One screen, plain English."""
import datetime as dt
import json
import os
import shutil
import socket
import sys

WORK = os.environ.get("WORK_DIR", "/tmp/bps")
OUT = os.environ.get("OUT_DIR", "/out")
ok = True


def line(good, text):
    global ok
    ok = ok and good
    print(("  OK    " if good else "  !!    ") + text)


def main():
    now = dt.datetime.now(dt.timezone.utc)
    print(f"BPS streamer check, {now:%Y-%m-%d %H:%M} UTC\n")
    try:
        st = json.load(open(os.path.join(WORK, "status.json")))
    except (OSError, ValueError):
        print("  !!    no status yet: the building has not published anything.\n"
              "        Wait 2 minutes after starting, then run check again. If it stays\n"
              "        like this, run:  docker logs bps")
        sys.exit(1)

    pv = st["panel"]
    print(f"  Building: {st['student']} in {st['city']}, panel {pv['kWp']:g} kWp, "
          f"tilt {pv['tilt_deg']:g}, facing {pv['azimuth_deg']:g}\n")

    last = dt.datetime.strptime(st["last_sent"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=dt.timezone.utc)
    age = (now - last).total_seconds() / 60
    line(age < 25, f"last reading sent {age:.0f} minutes ago ({st['last_sent']})"
         + ("" if age < 25 else ": readings should arrive every 10 minutes"))

    if os.environ.get("BROKER", "internal").lower() in ("", "internal"):
        port = int(os.environ.get("PORT", "1883"))
        try:
            socket.create_connection(("127.0.0.1", port), timeout=2).close()
            line(True, f"built-in MQTT broker is running on port {port}")
        except OSError:
            line(False, f"built-in MQTT broker is NOT running on port {port}")
    else:
        print(f"  --    using an external broker: {os.environ.get('BROKER')}")

    w = st["weather"]
    if w["quality"] == "ok":
        line(True, f"weather is real and up to date (downloaded {w['last_download']})")
    elif w["quality"] == "stale_weather":
        line(True, f"weather is {w['weather_age_h']} h old: {w['failures_in_a_row']} download(s) failed "
             f"in a row ({w['last_error']}). Readings continue; it retries every hour")
    else:
        line(False, f"no real weather yet ({w['last_error']}): typical-year weather is used. "
             f"Check the VM can reach api.open-meteo.com")

    csv_path = st.get("csv")
    if csv_path and os.path.exists(csv_path):
        rows = max(0, sum(1 for _ in open(csv_path)) - 1)
        line(True, f"{rows} readings saved in {os.path.basename(csv_path)} "
             f"({rows // 4} steps, about {rows / 4 / 144:.1f} days)")
    else:
        line(False, "no CSV copy found: did you add  -v ~/bps-out:/out  to docker run?")

    free = shutil.disk_usage(OUT).free / 1e9
    line(free > 1, f"{free:.1f} GB free on the disk" + ("" if free > 1 else ": the VM's disk is nearly full"))

    print("\n" + ("All good." if ok else "Something needs attention: see the !! lines above."))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
