"""Check the baked year and solar output for every city.

Run inside the streamer image (no MQTT needed):
  docker run --rm --entrypoint python3 ghcr.io/gcuiot/bps-streamer:latest /app/check_cities.py
Prints one line per city and PASS/FAIL, then a summary. Exit code 1 if any city fails.
"""
import datetime as dt
import json
import math
import os
import sys

sys.path.insert(0, os.environ.get("APP_DIR", "/app"))
import streamer          # noqa: E402
import solar             # noqa: E402
from weather import read_tmy  # noqa: E402

ZONES = ("office_a", "office_b", "corridor")


def check(cid):
    city = streamer.load_city(cid)
    year, data = streamer.load_baked(cid)
    sky = solar.Sky(read_tmy(city["tmy"])[1], year, city["lat"], city["longdiff"])
    problems = []

    steps = sorted(data)
    expected = 365 * 144
    if len(steps) != expected:
        problems.append(f"{len(steps)} steps, expected {expected}")
    missing = sum(1 for t in steps if set(data[t]) != set(ZONES))
    if missing:
        problems.append(f"{missing} steps missing a zone")

    heat = cool = pv = 0.0
    tmin, tmax = 1e9, -1e9
    tied = free = 0
    night_pv = 0.0
    pv_by_month = [0.0] * 13
    out_by_month = [[0.0, 0] for _ in range(13)]
    noon_peak = [0.0] * 24
    act = [any(r["heat_W"] > 0 or r["cool_W"] > 0 for r in data[t].values()) for t in steps]
    for i, t in enumerate(steps):
        z = data[t]
        for r in z.values():
            heat += r["heat_W"] / 6000
            cool += r["cool_W"] / 6000
            tmin, tmax = min(tmin, r["air_temp"]), max(tmax, r["air_temp"])
        if not any(act[max(0, i - 6):i + 7]):   # no plant for the surrounding hour
            free += 1
            if len({round(r["air_temp"], 2) for r in z.values()}) == 1:
                tied += 1
        s = sky.at(t)
        e = s["pv_W"] / 6000
        pv += e
        pv_by_month[t.month] += e
        noon_peak[t.hour] += e
        winter = (t.month in (6, 7)) if city["lat"] < 0 else (t.month in (12, 1))
        if t.hour in (0, 1, 2, 3, 22, 23) and winter:   # summer nights can be light far north
            night_pv += e
        o = out_by_month[t.month]
        o[0] += z[ZONES[0]]["outdoor_temp"]; o[1] += 1

    per_kwp = pv / solar.PV_KWP
    jan = out_by_month[1][0] / max(1, out_by_month[1][1])
    jul = out_by_month[7][0] / max(1, out_by_month[7][1])
    peak_hour = max(range(24), key=lambda h: noon_peak[h])

    if tied > 0.01 * max(1, free):
        problems.append(f"{tied} unheated steps with identical room temps")
    if not (-40 <= tmin and tmax <= 45):
        problems.append(f"room temps out of range {tmin:.1f}..{tmax:.1f}")
    if night_pv > 0.001:
        problems.append(f"solar at night ({night_pv:.2f} kWh)")
    if not 10 <= peak_hour <= 14:
        problems.append(f"solar peaks at {peak_hour}:00 local standard time")
    if not 400 <= per_kwp <= 2600:
        problems.append(f"PV yield {per_kwp:.0f} kWh/kWp")
    south = city["lat"] < 0
    if abs(city["lat"]) > 20:
        if (jul > jan) == south:
            problems.append(f"seasons wrong way round (Jan {jan:.1f}, Jul {jul:.1f})")
        summer_pv = pv_by_month[1] if south else pv_by_month[7]
        winter_pv = pv_by_month[7] if south else pv_by_month[1]
        if summer_pv <= winter_pv:
            problems.append("more solar in winter than summer")

    return {
        "city": cid, "heat": heat, "cool": cool, "pv": pv, "per_kwp": per_kwp,
        "tmin": tmin, "tmax": tmax, "jan": jan, "jul": jul, "peak": peak_hour,
        "tied": tied, "problems": problems,
    }


def main():
    cities = json.load(open(os.path.join(streamer.APP, "cities.json")))
    print(f"{'city':10s} {'heat kWh':>9s} {'cool kWh':>9s} {'PV kWh':>7s} {'kWh/kWp':>8s} "
          f"{'room min..max':>14s} {'out Jan/Jul':>12s} {'PV peak':>8s}  result")
    failed = 0
    for cid in cities:
        try:
            r = check(cid)
        except Exception as e:  # noqa: BLE001
            print(f"{cid:10s} ERROR {type(e).__name__}: {e}")
            failed += 1
            continue
        ok = not r["problems"]
        failed += not ok
        print(f"{cid:10s} {r['heat']:9.0f} {r['cool']:9.0f} {r['pv']:7.0f} {r['per_kwp']:8.0f} "
              f"{r['tmin']:6.1f}..{r['tmax']:5.1f} {r['jan']:5.1f}/{r['jul']:5.1f} {r['peak']:6d}:00  "
              + ("PASS" if ok else "FAIL: " + "; ".join(r["problems"])))
    print(f"\n{len(cities) - failed} of {len(cities)} cities passed")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
