"""Sunshine and rooftop PV for the BPS streamer.

Uses the same hourly weather ESP-r is given (diffuse horizontal and direct
normal irradiance, dry bulb), so the solar numbers always match the
simulation. Values are interpolated to the middle of each 10-minute step.

  solar_W_m2  global horizontal irradiance: sunshine on flat ground, W/m2
  poa_W_m2    irradiance on the tilted panel ('plane of array'), W/m2
  pv_W        average AC power from the rooftop array during the step, W

PV model (simple and standard): isotropic sky on the tilted plane, cell
temperature from NOCT, -0.4 %/K temperature coefficient, 14 % system losses.
"""
import datetime as dt
import math
import os

PV_KWP = float(os.environ.get("PV_KWP", "3.0"))        # array size, kWp (~15 m2)
PV_TILT = float(os.environ.get("PV_TILT", "30"))       # degrees from horizontal
PV_AZIMUTH = os.environ.get("PV_AZIMUTH")              # degrees from north, clockwise
ALBEDO = 0.2
NOCT = 45.0
TEMP_COEFF = -0.004
SYSTEM_EFF = 0.86


def pv_config(lat):
    az = float(PV_AZIMUTH) if PV_AZIMUTH not in (None, "") else (180.0 if lat >= 0 else 0.0)
    return {"kWp": PV_KWP, "tilt_deg": PV_TILT, "azimuth_deg": az}


class Sky:
    """Solar values for any local-standard-time instant, from 365x24 climate rows.

    Row h (1..24) of day D is the instant D h:00 local standard time, as in
    the ESP-r climate file; values are interpolated linearly between rows.
    """

    def __init__(self, days, year, lat, longdiff):
        self.days, self.year = days, year
        self.lat = math.radians(lat)
        self.longdiff = longdiff
        cfg = pv_config(lat)
        self.tilt = math.radians(cfg["tilt_deg"])
        self.az = math.radians(cfg["azimuth_deg"])

    def _row(self, instant):
        """Climate row at an exact hour instant (local standard time)."""
        if instant.hour == 0:
            day, h = (instant - dt.timedelta(days=1)).date(), 24
        else:
            day, h = instant.date(), instant.hour
        if day.month == 2 and day.day == 29:
            day = day.replace(day=28)
        try:
            day = day.replace(year=self.year)
        except ValueError:
            day = day.replace(year=self.year, day=28)
        doy = (day - dt.date(self.year, 1, 1)).days
        if day.month > 2 and _is_leap(self.year):
            doy -= 1
        doy = min(max(doy, 0), 364)
        return self.days[doy][h - 1]

    def _weather(self, t):
        t0 = t.replace(minute=0, second=0, microsecond=0)
        f = (t - t0).total_seconds() / 3600.0
        a, b = self._row(t0), self._row(t0 + dt.timedelta(hours=1))
        lerp = lambda i: a[i] + (b[i] - a[i]) * f
        return lerp(0), lerp(2), lerp(1) / 10.0   # diffuse, direct normal, dry bulb degC

    def _sun(self, t):
        """-> (cos zenith, solar azimuth from north clockwise, radians)."""
        n = t.timetuple().tm_yday
        g = 2 * math.pi * (n - 1) / 365.0
        decl = (0.006918 - 0.399912 * math.cos(g) + 0.070257 * math.sin(g)
                - 0.006758 * math.cos(2 * g) + 0.000907 * math.sin(2 * g)
                - 0.002697 * math.cos(3 * g) + 0.00148 * math.sin(3 * g))
        eot = 229.18 * (0.000075 + 0.001868 * math.cos(g) - 0.032077 * math.sin(g)
                        - 0.014615 * math.cos(2 * g) - 0.040849 * math.sin(2 * g))
        minutes = t.hour * 60 + t.minute + t.second / 60.0 + 4.0 * self.longdiff + eot
        ha = math.radians(minutes / 4.0 - 180.0)
        cz = (math.sin(self.lat) * math.sin(decl)
              + math.cos(self.lat) * math.cos(decl) * math.cos(ha))
        cz = max(-1.0, min(1.0, cz))
        sz = math.sqrt(max(0.0, 1 - cz * cz))
        if sz < 1e-6:
            return cz, 0.0
        caz = (math.sin(decl) - math.sin(self.lat) * cz) / (math.cos(self.lat) * sz)
        az = math.acos(max(-1.0, min(1.0, caz)))
        if ha > 0:
            az = 2 * math.pi - az
        return cz, az

    def at(self, step_end):
        """Solar values for the 10-minute step ending at step_end (local standard time)."""
        t = step_end - dt.timedelta(minutes=5)
        dhi, dni, tair = self._weather(t)
        dhi, dni = max(0.0, dhi), max(0.0, dni)
        cz, saz = self._sun(t)
        if cz <= 0.0:
            return {"solar_W_m2": 0.0, "poa_W_m2": 0.0, "pv_W": 0.0}
        ghi = dhi + dni * cz
        sz = math.sqrt(max(0.0, 1 - cz * cz))
        cos_aoi = (cz * math.cos(self.tilt)
                   + sz * math.sin(self.tilt) * math.cos(saz - self.az))
        poa = (dni * max(0.0, cos_aoi)
               + dhi * (1 + math.cos(self.tilt)) / 2
               + ghi * ALBEDO * (1 - math.cos(self.tilt)) / 2)
        t_cell = tair + poa * (NOCT - 20.0) / 800.0
        pv = PV_KWP * 1000.0 * poa / 1000.0 * (1 + TEMP_COEFF * (t_cell - 25.0)) * SYSTEM_EFF
        return {"solar_W_m2": ghi, "poa_W_m2": poa, "pv_W": max(0.0, pv)}


def _is_leap(y):
    return y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)
