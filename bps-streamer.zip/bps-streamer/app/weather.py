"""Live weather for the BPS streamer.

Fetches recent observed + forecast hourly weather from Open-Meteo (free, no API
key) and writes an ESP-r ASCII climate file. The file starts as the city's
bundled typical year (TMY); the days covered by real weather are overwritten,
so ESP-r always has a complete, valid year to read.

ESP-r ASCII climate rows, per hour, comma separated:
  diffuse horizontal W/m2, dry bulb (tenths degC), direct normal W/m2,
  wind speed (tenths m/s), wind direction (deg from N), relative humidity (%)
Each day block has 24 rows for hours 1..24 in the climate file's own time base
(local standard time, i.e. UTC + std_offset_h, no daylight saving).
"""
import datetime as dt
import json
import os
import urllib.parse
import urllib.request

OPEN_METEO = "https://api.open-meteo.com/v1/forecast"
HOURLY_VARS = [
    "temperature_2m", "relative_humidity_2m", "wind_speed_10m",
    "wind_direction_10m", "diffuse_radiation", "direct_normal_irradiance",
]


def fetch_open_meteo(lat, lon, past_days=3, forecast_days=2, timeout=30):
    """Return the parsed Open-Meteo JSON (hourly, times in UTC).

    WEATHER_FILE=<path> loads a saved Open-Meteo response instead of calling
    the API (offline demos and testing).
    """
    override = os.environ.get("WEATHER_FILE")
    if override:
        with open(override) as f:
            return json.load(f)
    q = urllib.parse.urlencode({
        "latitude": lat, "longitude": lon,
        "hourly": ",".join(HOURLY_VARS),
        "past_days": past_days, "forecast_days": forecast_days,
        "timezone": "GMT", "wind_speed_unit": "ms",
    })
    req = urllib.request.Request(f"{OPEN_METEO}?{q}",
                                 headers={"User-Agent": "gcu-bps-streamer/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def hourly_records(om_json, std_offset_h):
    """Map Open-Meteo hourly data to {(local_std_date, hour 1..24): row}.

    Open-Meteo timestamps are instants in UTC. ESP-r row h of day D is the
    instant D h:00 local standard time (h=24 is midnight ending day D).
    """
    h = om_json["hourly"]
    out = {}
    for i, t in enumerate(h["time"]):
        utc = dt.datetime.fromisoformat(t)
        local = utc + dt.timedelta(hours=std_offset_h)
        if local.hour == 0:
            day, hour = (local - dt.timedelta(days=1)).date(), 24
        else:
            day, hour = local.date(), local.hour
        vals = [h[v][i] for v in HOURLY_VARS]
        if any(v is None for v in vals):
            continue  # gaps: keep the TMY value for that hour
        temp, rh, ws, wd, dif, dni = vals
        out[(day, hour)] = (
            int(round(dif)), int(round(temp * 10)), int(round(dni)),
            int(round(ws * 10)), int(round(wd)) % 360,
            max(0, min(100, int(round(rh)))),
        )
    return out


def read_tmy(path):
    """Parse a bundled ESP-r ASCII climate file -> (header_lines, rows[365][24])."""
    header, days, cur = [], [], None
    with open(path) as f:
        for line in f:
            s = line.strip()
            if s.startswith("* day"):
                cur = []
                days.append(cur)
                continue
            if cur is None:
                header.append(line.rstrip("\n"))
                continue
            if not s or s.startswith("#"):
                continue
            nums = [int(float(x)) for x in s.split("#")[0].replace(",", " ").split()[:6]]
            cur.append(tuple(nums))
    if len(days) != 365 or any(len(d) != 24 for d in days):
        raise ValueError(f"{path}: expected 365 days x 24 hours")
    return header, days


def write_climate(path, header, days, year, site_name=None):
    """Write an ESP-r ASCII climate file, replacing the year in the header."""
    with open(path, "w") as f:
        seen_site = False
        for line in header:
            body = line.split("#")[0].strip()
            if body and not line.lstrip().startswith(("*", "#")):
                if not seen_site:
                    seen_site = True
                    if site_name:
                        line = f"{site_name}    # site name"
                elif body.split(",")[0].strip().isdigit() and len(body.split(",")) >= 3:
                    parts = [p.strip() for p in body.split(",")]
                    if len(parts[0]) == 4:  # the year,lat,longdiff,... line
                        parts[0] = str(year)
                        line = " " + ",".join(parts) + "   # year latitude long diff rad flag"
            f.write(line + "\n")
        start = dt.date(year, 1, 1)
        for d in range(365):
            date = start + dt.timedelta(days=d)
            f.write(f"* day {date.day:2d} month {date.month:2d}\n")
            for row in days[d]:
                f.write(" " + ",".join(str(v) for v in row) + "\n")


def overlay(days, records, year):
    """Overwrite TMY rows with real-weather records falling inside `year`.

    Returns the number of hours replaced. 29 Feb (leap years) is skipped,
    because ESP-r climate files hold 365 days.
    """
    n = 0
    for (date, hour), row in records.items():
        if date.year != year or (date.month == 2 and date.day == 29):
            continue
        doy = (date - dt.date(year, 1, 1)).days
        if date.month > 2 and _is_leap(year):
            doy -= 1
        days[doy][hour - 1] = row
        n += 1
    return n


def _is_leap(y):
    return y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)
