"""Drive ESP-r: prepare the model for a city/period, run bps, read results."""
import csv
import datetime as dt
import os
import re
import shutil
import subprocess

ESP = os.environ.get("ESP_HOME", "/opt/esp-r")
MODEL_SRC = os.environ.get("MODEL_DIR", "/app/model")
CFG_NAME = "office.cfg"
CTL_NAME = "office.ctl"
TIMESTEPS_PER_HOUR = 6  # 10-minute steps


def calendar_list(year):
    """ESP-r day-type list for 365 days: 1 weekday, 2 Saturday, 3 Sunday."""
    out, d = [], dt.date(year, 1, 1)
    while len(out) < 365:
        if not (d.month == 2 and d.day == 29):
            wd = d.weekday()
            out.append(1 if wd < 5 else (2 if wd == 5 else 3))
        d += dt.timedelta(days=1)
    return out


def prepare(workdir, city, clm_path, year, start, end, startup_days, setpoint=None):
    """Copy the template model to workdir and patch it for this run.

    start/end are datetime.date inside `year`; clm_path is an ASCII climate file.
    """
    if os.path.exists(workdir):
        shutil.rmtree(workdir)
    shutil.copytree(MODEL_SRC, workdir)
    # ESP-r caps filename lengths, so convert and reference the climate
    # with short relative names inside the work folder.
    shutil.copyfile(clm_path, os.path.join(workdir, "climate.a"))
    climate_to_binary(workdir, "climate.a", "climate.bin")
    clm_bin = "../climate.bin"   # relative to the cfg folder
    cfg = os.path.join(workdir, "cfg", CFG_NAME)
    text = open(cfg).read()

    # site: latitude & longitude difference from the climate's reference meridian
    text = re.sub(r"(?m)^\s*-?\d+\.\d+\s+-?\d+\.\d+\s+# latitude & longitude difference.*$",
                  f" {city['lat']:7.3f}  {city['longdiff']:7.3f}                # latitude & longitude difference (from reference meridian)",
                  text)
    # climate: model-local ASCII climate file
    text = re.sub(r"(?m)^\*stdclm .*$", f"*clm {clm_bin}", text)
    text = re.sub(r"(?m)^\*clm .*$", f"*clm {clm_bin}", text)
    text = re.sub(r"(?m)^\*year \d+", f"*year {year}", text)

    # calendar for the real year so weekdays/weekends line up
    cal = calendar_list(year)
    counts = {k: cal.count(k) for k in (1, 2, 3)}
    text = re.sub(r"(?m)^\*calentag weekdays,.*$", f"*calentag weekdays, weekdays (all year), {counts[1]}", text)
    text = re.sub(r"(?m)^\*calentag saturday,.*$", f"*calentag saturday, Saturdays (all year), {counts[2]}", text)
    text = re.sub(r"(?m)^\*calentag sunday,.*$", f"*calentag sunday, Sundays (all year), {counts[3]}", text)
    rows = [",".join(str(v) for v in cal[i:i + 47]) + "," for i in range(0, 365, 47)]
    rows[-1] = rows[-1].rstrip(",")
    text = re.sub(r"(?s)\*list\s+3.*?\*end_list",
                  "*list    3   # day types & type for each day of year\n " +
                  "\n ".join(rows) + "\n*end_list", text)

    # one simulation parameter set: 10-minute steps, our period
    sps = (f"*sps    1  {startup_days}  {TIMESTEPS_PER_HOUR}  10   4   0   # sets, startup, zone & plant ts, save level\n"
           f"  {start.day}  {start.month}  {end.day}  {end.month}  run\n"
           f"*sblr run.res\n*end_set\n*end_sps")
    text = re.sub(r"(?s)\*sps\s.*?\*end_sps", sps, text)
    open(cfg, "w").write(text)

    if setpoint is not None:
        set_heating_setpoint(os.path.join(workdir, "ctl", CTL_NAME), setpoint)
    return cfg


def climate_to_binary(workdir, ascii_name, bin_name):
    """Convert an ASCII climate file to ESP-r's binary format with clm."""
    bin_path = os.path.join(workdir, bin_name)
    if os.path.exists(bin_path):
        os.remove(bin_path)
    cmd = [os.path.join(ESP, "bin", "clm"), "-mode", "text", "-file", bin_name,
           "-act", "asci2bin", "silent", ascii_name]
    r = subprocess.run(cmd, cwd=workdir, capture_output=True, text=True, timeout=300)
    if not os.path.exists(bin_path) or os.path.getsize(bin_path) < 300000:
        raise RuntimeError(f"clm could not convert the climate file: {r.stdout[-500:]}{r.stderr[-500:]}")
    return bin_path


def set_heating_setpoint(ctl_path, setpoint):
    """Replace the occupied-hours heating setpoint (19 C in the template)."""
    lines = open(ctl_path).read().splitlines()
    out = []
    for ln in lines:
        if "basic control" in ln and "heating setpoint 19.00C" in ln:
            nums = ln.split("#")[0].split()
            nums[4] = f"{float(setpoint):.3f}"
            ln = " " + " ".join(nums) + f"  # basic control, heating setpoint {float(setpoint):.2f}C (patched)"
        out.append(ln)
    open(ctl_path, "w").write("\n".join(out) + "\n")


def run_bps(cfg, log_path, timeout=900):
    """Run the simulation non-interactively; H3K writes out.csv beside the cfg."""
    cfgdir = os.path.dirname(cfg)
    for f in ("out.csv", "out.xml", "out.dictionary"):
        p = os.path.join(cfgdir, f)
        if os.path.exists(p):
            os.remove(p)
    cmd = [os.path.join(ESP, "bin", "bps"), "-file", os.path.basename(cfg),
           "-mode", "text", "-p", "run", "silent"]
    with open(log_path, "w") as log:
        r = subprocess.run(cmd, cwd=cfgdir, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    out = os.path.join(cfgdir, "out.csv")
    if r.returncode != 0 or not os.path.exists(out):
        raise RuntimeError(f"bps failed (exit {r.returncode}); see {log_path}")
    return out
