"""Read ESP-r H3K out.csv into timestamped per-zone readings.

Row k (0-based) of a run starting on date D covers the 10-minute step ending at
D 00:00 + (k+1)*10 min, in the climate file's local standard time. Every row is
cross-checked against ESP-r's own 'time:future' column.
"""
import csv
import datetime as dt

ZONES = {"manager a": "office_a", "manager b": "office_b", "coridor": "corridor"}
STEP = dt.timedelta(minutes=10)


def read(path, start_date, std_offset_h):
    """Return [(ts_utc, {zone: {air_temp, heat_W, cool_W, outdoor_temp}})]."""
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    hdr = [h.strip() for h in rows[0] if h.strip()]
    col = {h: i for i, h in enumerate(hdr)}

    def need(name):
        if name not in col:
            raise RuntimeError(f"results column missing: {name}")
        return col[name]

    t_future = need("building:time:future (hours)")
    t_out = need("climate:dry bulb temperature (oC)")
    zc = {}
    for esp_name, zone in ZONES.items():
        zc[zone] = (need(f"building:{esp_name}:air point:temperature (oC)"),
                    need(f"building:{esp_name}:supplied energy:heating (W)"),
                    need(f"building:{esp_name}:supplied energy:cooling (W)"))

    t0 = dt.datetime.combine(start_date, dt.time(0, 0))
    off = dt.timedelta(hours=std_offset_h)
    out = []
    for k, r in enumerate(rows[1:]):
        v = [x.strip() for x in r if x.strip()]
        if not v:
            continue
        v = [float(x) for x in v]
        local = t0 + (k + 1) * STEP
        hours = local.hour + local.minute / 60
        esp_h = v[t_future] % 24.0
        if abs(hours - esp_h) > 0.02 and abs(abs(hours - esp_h) - 24) > 0.02:
            raise RuntimeError(f"time axis mismatch at row {k}: computed {local:%H:%M}, "
                               f"ESP-r reports {v[t_future]:.3f} h")
        ts = (local - off).replace(tzinfo=dt.timezone.utc)
        zones = {z: {"air_temp": v[a], "heat_W": v[h], "cool_W": v[c],
                     "outdoor_temp": v[t_out]} for z, (a, h, c) in zc.items()}
        out.append((ts, zones))
    return out
