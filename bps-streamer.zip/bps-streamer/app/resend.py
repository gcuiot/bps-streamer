"""docker exec bps resend FROM TO  ->  publish saved readings again, from the CSV copy.

For when your flow or database was down: the building kept running and kept a CSV
copy in /out, but those MQTT messages were missed. This publishes the readings
between FROM and TO (UTC, inclusive) again, on the same topics and in the same
format, so your own flow stores them as usual.

  docker exec bps resend 2026-11-23T10:00 2026-11-23T14:00
  docker exec bps resend 2026-11-23 2026-11-23          (a whole day)
  docker exec bps resend 2026-11-23 2026-11-23 --dry-run (count only)

Resend only a gap: readings you already stored would be stored twice.
"""
import csv
import datetime as dt
import glob
import json
import os
import sys
import time
from zoneinfo import ZoneInfo

import paho.mqtt.client as mqtt

APP = os.path.dirname(os.path.abspath(__file__))
OUT = os.environ.get("OUT_DIR", "/out")
NUMBERS = ("air_temp", "heat_W", "cool_W", "outdoor_temp", "pv_W", "poa_W_m2", "solar_W_m2", "weather_age_h")


def parse(s, end):
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            t = dt.datetime.strptime(s.rstrip("Z"), fmt).replace(tzinfo=dt.timezone.utc)
        except ValueError:
            continue
        if end and fmt == "%Y-%m-%d":
            t += dt.timedelta(days=1) - dt.timedelta(seconds=1)   # whole day
        return t
    sys.exit(f"resend: cannot read the time '{s}': use e.g. 2026-11-23T10:00 (UTC)")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    dry = "--dry-run" in sys.argv
    if len(args) != 2:
        sys.exit(__doc__)
    t0, t1 = parse(args[0], False), parse(args[1], True)
    if t1 < t0:
        sys.exit("resend: the second time is before the first")

    student = os.environ.get("STUDENT", "").strip()
    cid = os.environ.get("CITY", "").strip().lower()
    city = json.load(open(os.path.join(APP, "cities.json"))).get(cid)
    if not student or not city:
        sys.exit("resend: STUDENT or CITY is not set in this container")
    tz = ZoneInfo(city["tz"])
    path = os.path.join(OUT, f"{student}_{cid}_live.csv")
    if not os.path.exists(path):
        found = glob.glob(os.path.join(OUT, f"{student}_{cid}_*.csv"))
        if not found:
            sys.exit(f"resend: no CSV copy in {OUT}: was the container started with -v ~/bps-out:/out ?")
        path = found[0]

    msgs = []
    for row in csv.DictReader(open(path, newline="")):
        try:
            ts = dt.datetime.strptime(row["ts"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=dt.timezone.utc)
        except (KeyError, ValueError):
            continue
        if not t0 <= ts <= t1:
            continue
        m = {"ts": row["ts"], "city": cid, "zone": row["zone"]}
        for k in NUMBERS:
            if row.get(k, "") != "":
                m[k] = float(row[k])
        m["local_hour"] = ts.astimezone(tz).hour
        m["quality"] = row.get("quality") or "ok"
        if "weather_age_h" in m:            # keep the original field order
            m["weather_age_h"] = m.pop("weather_age_h")
        msgs.append(m)

    steps = len({m["ts"] for m in msgs})
    print(f"{len(msgs)} readings ({steps} steps of 10 minutes) between "
          f"{t0:%Y-%m-%d %H:%M} and {t1:%Y-%m-%d %H:%M} UTC in {os.path.basename(path)}")
    if not msgs or dry:
        return

    broker = os.environ.get("BROKER", "internal").strip()
    host = "127.0.0.1" if broker.lower() in ("", "internal") else broker
    port = int(os.environ.get("PORT", "1883"))
    prefix = os.environ.get("TOPIC_PREFIX", "bps")
    cid_mqtt = f"bps-{student}-resend-{os.getpid()}"   # never the streamer's own client id
    if hasattr(mqtt, "CallbackAPIVersion"):
        c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=cid_mqtt)
    else:
        c = mqtt.Client(client_id=cid_mqtt)
    if os.environ.get("MQTT_USER"):
        c.username_pw_set(os.environ["MQTT_USER"], os.environ.get("MQTT_PASS"))
    try:
        c.connect(host, port, keepalive=60)
    except OSError as e:
        sys.exit(f"resend: cannot reach the broker {host}:{port} ({e})")
    c.loop_start()
    pending = []
    for m in msgs:
        pending.append(c.publish(f"{prefix}/{student}/{cid}/{m['zone']}/env", json.dumps(m), qos=1))
        if len(pending) >= 200:          # pace it, so a flow is not flooded
            for p in pending:
                p.wait_for_publish(timeout=30)
            pending = []
            time.sleep(0.2)
    for p in pending:
        p.wait_for_publish(timeout=30)
    c.loop_stop()
    c.disconnect()
    print(f"sent {len(msgs)} readings again: check your database has them")


if __name__ == "__main__":
    main()
