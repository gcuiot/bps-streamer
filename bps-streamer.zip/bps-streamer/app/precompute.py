"""Build-time step: simulate a typical year for every city and bake the results.

Run inside the image build. Any failure stops the build, so a broken
simulation can never reach a student. Output per city:
  <out>/<city>.csv.gz with columns
  local,zone,air_temp,heat_W,cool_W,outdoor_temp
where 'local' is the end of each 10-minute step in the climate file's local
standard time (no daylight saving), for the calendar year BAKE_YEAR.
"""
import csv
import datetime as dt
import gzip
import json
import os
import sys
import time

import esp
import results
import weather

APP = os.path.dirname(os.path.abspath(__file__))
EXPECTED_STEPS = 365 * 144


def bake(cid, city, climate_dir, out_dir, work, year):
    header, days = weather.read_tmy(os.path.join(climate_dir, city["climate"] + ".a"))
    clm = os.path.join(work, "climate.a")
    weather.write_climate(clm, header, days, year)
    cfg = esp.prepare(os.path.join(work, "model"), dict(city, id=cid), clm, year,
                      dt.date(year, 1, 1), dt.date(year, 12, 31), 3)
    out = esp.run_bps(cfg, os.path.join(work, f"bps_{cid}.log"))
    steps = results.read(out, dt.date(year, 1, 1), 0)   # offset 0 -> local standard time
    if len(steps) != EXPECTED_STEPS:
        raise RuntimeError(f"{cid}: {len(steps)} steps, expected {EXPECTED_STEPS}")
    for ts, zones in steps:
        for z, r in zones.items():
            for k, v in r.items():
                if v != v or abs(v) > 1e6:   # NaN or absurd value
                    raise RuntimeError(f"{cid}: bad {k}={v} at {ts} {z}")
    # Free-running zones (no heating or cooling anywhere) must not all share one
    # temperature: that means something in the model is coupling them.
    tied = sum(1 for _, zones in steps
               if all(r["heat_W"] == 0 and r["cool_W"] == 0 for r in zones.values())
               and len({round(r["air_temp"], 2) for r in zones.values()}) == 1)
    if tied > 0.01 * len(steps):
        raise RuntimeError(f"{cid}: {tied} free-running steps with identical zone temperatures")
    path = os.path.join(out_dir, f"{cid}.csv.gz")
    with gzip.open(path, "wt", newline="") as f:
        w = csv.writer(f)
        w.writerow(["local", "zone", "air_temp", "heat_W", "cool_W", "outdoor_temp"])
        for ts, zones in steps:
            for z, r in zones.items():
                w.writerow([ts.strftime("%Y-%m-%dT%H:%M"), z, round(r["air_temp"], 2),
                            round(r["heat_W"], 1), round(r["cool_W"], 1),
                            round(r["outdoor_temp"], 2)])
    return len(steps)


def main():
    climate_dir, out_dir = sys.argv[1], sys.argv[2]
    year = int(os.environ.get("BAKE_YEAR", "2026"))
    only = sys.argv[3:]   # optional subset of cities, for testing
    work = os.environ.get("WORK_DIR", "/tmp/bake")
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(work, exist_ok=True)
    cities = json.load(open(os.path.join(APP, "cities.json")))
    for cid in (only or sorted(cities)):
        t = time.time()
        n = bake(cid, cities[cid], climate_dir, out_dir, work, year)
        print(f"[bake] {cid:10s} {n} steps x 3 zones in {time.time() - t:.0f}s", flush=True)
    json.dump({"year": year}, open(os.path.join(out_dir, "baked.json"), "w"))
    print(f"[bake] all done ({year})", flush=True)


if __name__ == "__main__":
    main()
