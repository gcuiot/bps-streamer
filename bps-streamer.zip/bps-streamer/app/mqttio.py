"""MQTT publishing for the BPS streamer: retained meta, Last Will status, readings."""
import json
import sys
import time

import paho.mqtt.client as mqtt


class Publisher:
    def __init__(self, broker, port, student, prefix="bps", user=None, password=None):
        self.prefix, self.student = prefix, student
        self.status_topic = f"{prefix}/{student}/status"
        self.meta_topic = f"{prefix}/{student}/meta"
        cid = f"bps-{student}"
        if hasattr(mqtt, "CallbackAPIVersion"):          # paho-mqtt 2.x
            self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,
                                      client_id=cid, clean_session=True)
        else:                                            # paho-mqtt 1.x (Ubuntu 24.04)
            self.client = mqtt.Client(client_id=cid, clean_session=True)
        if user:
            self.client.username_pw_set(user, password)
        # Last Will: if the streamer dies, the broker announces it.
        self.client.will_set(self.status_topic, "offline", qos=1, retain=True)
        self.client.reconnect_delay_set(min_delay=1, max_delay=30)
        self.broker, self.port = broker, port
        self._pending = []

    def connect(self, attempts=30):
        for i in range(attempts):
            try:
                self.client.connect(self.broker, self.port, keepalive=60)
                self.client.loop_start()
                self.client.publish(self.status_topic, "online", qos=1, retain=True)
                return
            except OSError as e:
                print(f"[mqtt] cannot reach {self.broker}:{self.port} ({e}); "
                      f"retry {i + 1}/{attempts}", flush=True)
                time.sleep(2)
        sys.exit(f"[mqtt] giving up: broker {self.broker}:{self.port} unreachable")

    def meta(self, payload):
        self.client.publish(self.meta_topic, json.dumps(payload), qos=1, retain=True).wait_for_publish()

    def reading(self, city, zone, payload):
        """Publish one reading, with backpressure so fast replays never overflow
        the client's queue: at most MAX_PENDING unacknowledged messages."""
        topic = f"{self.prefix}/{self.student}/{city}/{zone}/env"
        data = json.dumps(payload)
        while True:
            info = self.client.publish(topic, data, qos=1)
            if info.rc == mqtt.MQTT_ERR_SUCCESS or info.rc == mqtt.MQTT_ERR_NO_CONN:
                break   # NO_CONN: queued, paho resends after reconnecting
            self._drain(0)  # queue full: wait for acks, then retry
        self._pending.append(info)
        if len(self._pending) > self.MAX_PENDING:
            self._drain(self.MAX_PENDING // 2)
        return info

    MAX_PENDING = 500

    def _drain(self, keep):
        while len(self._pending) > keep:
            info = self._pending.pop(0)
            try:
                info.wait_for_publish(timeout=30)
            except (ValueError, RuntimeError):
                pass

    def finish(self, status="finished"):
        self._drain(0)
        self.client.publish(self.status_topic, status, qos=1, retain=True).wait_for_publish()
        self.client.loop_stop()
        self.client.disconnect()
