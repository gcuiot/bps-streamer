"""BPS streamer: an ESP-r simulated building, streamed over MQTT.

MODE=replay  play back the city's baked typical year (simulated with ESP-r
             when the image was built) at SPEED simulated seconds per real
             second. No simulation runs at all, so nothing can fail here.
MODE=live    once an hour, rebuild yesterday-to-tomorrow weather from
             Open-Meteo and re-simulate with ESP-r; every 10 minutes, publish
             the steps whose time has come. Every expected step is always
             published: if the simulation fails, the baked typical-year value
             is used and labelled in the 'quality' field.
"""
import csv
import datetime as dt
import gzip
import json
import os
import signal
import sys
import time
import traceback
from zoneinfo import ZoneInfo

from mqttio import Publisher
import solar
from weather import read_tmy

APP = os.path.dirname(os.path.abspath(__file__))
BAKED = os.environ.get("BAKED_DIR", "/app/baked")
CLIMATE_DIR = os.environ.get("CLIMATE_DIR", "/app/climate")
WORK = os.environ.get("WORK_DIR", "/tmp/bps")
OUT = os.environ.get("OUT_DIR", "/out")
HEARTBEAT = os.path.join(WORK, "heartbeat")
STEP = dt.timedelta(minutes=10)
ZONES = ("office_a", "office_b", "corridor")
PV_ZONE = "roof_pv"
CSV_FIELDS = ["ts", "zone", "air_temp", "heat_W", "cool_W", "outdoor_temp",
              "solar_W_m2", "pv_W", "quality", "weather_age_h", "poa_W_m2"]
MODEL_NAME = "3-zone cellular office (2 offices + corridor), ESP-r"
QUALITY = {
    "ok": "simulated with real weather (live) or the typical year (replay)",
    "stale_weather": "simulated, but the weather feed was down: last good weather reused",
    "typical_weather": "simulated, but no real weather was available: typical-year weather used",
    "typical_year": "simulation unavailable: baked typical-year value for this date and time",
}


def env(name, default=None, required=False):
    v = os.environ.get(name, default)
    if required and not v:
        sys.exit(f"[config] {name} must be set")
    return v


def beat():
    try:
        os.makedirs(WORK, exist_ok=True)
        with open(HEARTBEAT, "w") as f:
            f.write(str(time.time()))
    except OSError:
        pass


def load_city(cid):
    cities = json.load(open(os.path.join(APP, "cities.json")))
    if cid not in cities:
        sys.exit(f"[config] unknown CITY '{cid}'. Valid: {', '.join(sorted(cities))}")
    c = dict(cities[cid], id=cid)
    c["tmy"] = os.path.join(CLIMATE_DIR, c["climate"] + ".a")
    return c


def load_baked(cid):
    """-> (bake_year, {local_std_datetime: {zone: row}}) in step order."""
    year = json.load(open(os.path.join(BAKED, "baked.json")))["year"]
    data = {}
    with gzip.open(os.path.join(BAKED, f"{cid}.csv.gz"), "rt", newline="") as f:
        for r in csv.DictReader(f):
            t = dt.datetime.fromisoformat(r["local"])
            data.setdefault(t, {})[r["zone"]] = {
                k: float(r[k]) for k in ("air_temp", "heat_W", "cool_W", "outdoor_temp")}
    return year, data


def message(city, zone, ts_utc, row, tz, quality, sun, age_h=None):
    return {
        "ts": ts_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "city": city["id"], "zone": zone,
        "air_temp": round(row["air_temp"], 2),
        "heat_W": round(row["heat_W"], 1),
        "cool_W": round(row["cool_W"], 1),
        "outdoor_temp": round(row["outdoor_temp"], 2),
        "solar_W_m2": round(sun["solar_W_m2"], 1),
        "local_hour": ts_utc.astimezone(tz).hour,
        "quality": quality,
        **({"weather_age_h": age_h} if age_h is not None else {}),
    }


def pv_message(city, ts_utc, outdoor_temp, tz, quality, sun, age_h=None):
    """The rooftop solar array: a second kind of device, with its own fields."""
    return {
        "ts": ts_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "city": city["id"], "zone": PV_ZONE,
        "pv_W": round(sun["pv_W"], 1),
        "poa_W_m2": round(sun["poa_W_m2"], 1),
        "solar_W_m2": round(sun["solar_W_m2"], 1),
        "outdoor_temp": round(outdoor_temp, 2),
        "local_hour": ts_utc.astimezone(tz).hour,
        "quality": quality,
        **({"weather_age_h": age_h} if age_h is not None else {}),
    }


def publish_step(city, pub, ts, zones, tz, quality, sun, age_h=None):
    """Publish one 10-minute step: three zone readings and one PV reading."""
    out = []
    for z in ZONES:
        m = message(city, z, ts, zones[z], tz, quality, sun, age_h)
        pub.reading(city["id"], z, m)
        out.append(m)
    m = pv_message(city, ts, zones[ZONES[0]]["outdoor_temp"], tz, quality, sun, age_h)
    pub.reading(city["id"], PV_ZONE, m)
    out.append(m)
    return out


class CsvLog:
    """Append-only CSV side file; never allowed to stop the stream."""
    def __init__(self, path):
        self.path = path
        self.ok = True
        self.fields = None   # an older file keeps its own columns


    def write(self, rows):
        if not self.ok:
            return
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            new = not os.path.exists(self.path)
            if self.fields is None:
                self.fields = CSV_FIELDS
                if not new:
                    with open(self.path, newline="") as f:
                        head = next(csv.reader(f), None)
                    if head:
                        self.fields = head
            with open(self.path, "a", newline="") as f:
                w = csv.DictWriter(f, fieldnames=self.fields, restval="", extrasaction="ignore")
                if new:
                    w.writeheader()
                w.writerows(rows)
        except OSError as e:
            print(f"[out] cannot write {self.path} ({e}); continuing without it", flush=True)
            self.ok = False


# --------------------------------------------------------------------------- replay
def replay(city, pub, student, speed):
    tz = ZoneInfo(city["tz"])
    off = dt.timedelta(hours=city["std_offset_h"])
    year, data = load_baked(city["id"])
    sky = solar.Sky(read_tmy(city["tmy"])[1], year, city["lat"], city["longdiff"])
    print(f"[replay] typical year for {city['name']}: {len(data)} steps, "
          f"one every {STEP.total_seconds() / speed:.3f}s", flush=True)
    path = os.path.join(OUT, f"{student}_{city['id']}_{year}.csv")
    if os.path.exists(path):
        os.remove(path)
    log = CsvLog(path)
    interval = STEP.total_seconds() / speed
    t_next = time.monotonic()
    batch = []
    for i, (local, zones) in enumerate(sorted(data.items())):
        ts = (local - off).replace(tzinfo=dt.timezone.utc)
        batch.extend(publish_step(city, pub, ts, zones, tz, "ok", sky.at(local)))
        if len(batch) >= 3000:
            log.write(batch)
            batch = []
        if i % 100 == 0:
            beat()
        if i % 1008 == 0:
            print(f"[replay] {ts:%Y-%m-%d %H:%M} UTC ({i}/{len(data)})", flush=True)
        t_next += interval
        delay = t_next - time.monotonic()
        if delay > 0:
            time.sleep(delay)
    log.write(batch)
    print("[replay] complete", flush=True)



# --------------------------------------------------------------------------- weather
WEATHER_EVERY_S = float(env("WEATHER_EVERY_H", "1")) * 3600   # 3 is plenty if a VM runs many
_weather = {"om": None, "fetched": 0.0, "failed": 0.0,
            "ok_total": 0, "fail_total": 0, "fail_run": 0, "last_error": None}


_weather_past_days = [3]   # raised for the first simulation after a long gap


def _jitter_s():
    """A fixed delay of 0-59 s for this building, so many containers on one VM
    do not all ask Open-Meteo in the same second."""
    import hashlib
    key = (env("STUDENT", "") + env("CITY", "")).encode()
    return int(hashlib.md5(key).hexdigest(), 16) % 60


def get_weather(city, now=None, fetch=None, sleep=time.sleep):
    """-> (open_meteo_json or None, quality). Downloads at most every WEATHER_EVERY_H
    hours; after a failure, tries again an hour later and reuses the last good weather."""
    import weather
    now = time.time() if now is None else now
    fetch = fetch or (lambda: weather.fetch_open_meteo(city["lat"], city["lon"],
                                                       past_days=_weather_past_days[0]))
    w = _weather
    fresh = w["om"] is not None and now - w["fetched"] < WEATHER_EVERY_S
    if fresh and now - w["failed"] >= 3600 and w["failed"] > w["fetched"]:
        fresh = False                      # last attempt failed an hour ago: try again
    if fresh:
        return w["om"], "ok" if w["failed"] <= w["fetched"] else "stale_weather"
    if w["om"] is not None and w["failed"] > w["fetched"] and now - w["failed"] < 3600:
        return w["om"], "stale_weather"    # failed less than an hour ago: do not hammer
    if w["om"] is not None:
        sleep(_jitter_s())                 # spread out the regular refreshes
    try:
        w["om"], w["fetched"] = fetch(), now
        w["ok_total"] += 1
        w["fail_run"] = 0
        return w["om"], "ok"
    except Exception as e:
        w["failed"] = now
        w["fail_total"] += 1
        w["fail_run"] += 1
        w["last_error"] = str(e)[:200]
        quality = "stale_weather" if w["om"] is not None else "typical_weather"
        print(f"[weather] Open-Meteo unavailable ({e}); {quality}", flush=True)
        return w["om"], quality

def weather_age_h(now=None):
    """Hours since the weather in use was downloaded (None if there is none)."""
    if _weather["om"] is None:
        return None
    now = time.time() if now is None else now
    return round((now - _weather["fetched"]) / 3600, 1)


def weather_status(quality):
    """Retained on bps/<student>/weather after every simulation: how fresh the weather is."""
    w = _weather
    iso = lambda t: dt.datetime.fromtimestamp(t, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") if t else None
    return {"checked": iso(time.time()), "quality": quality,
            "last_download": iso(w["fetched"]), "weather_age_h": weather_age_h(),
            "failures_in_a_row": w["fail_run"], "failures_total": w["fail_total"],
            "downloads_ok": w["ok_total"], "last_error": w["last_error"]}


# --------------------------------------------------------------------------- resume + status
CATCH_UP_DAYS = 7


def _write_json(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.replace(tmp, path)


def load_last_sent(path, default, now):
    """Carry on after the last reading sent before a restart (at most CATCH_UP_DAYS back)."""
    try:
        with open(path) as f:
            last = dt.datetime.strptime(json.load(f)["last_sent"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=dt.timezone.utc)
    except (OSError, ValueError, KeyError):
        return default, False
    oldest = now - dt.timedelta(days=CATCH_UP_DAYS)
    if last < oldest:
        last = oldest.replace(minute=oldest.minute - oldest.minute % 10, second=0, microsecond=0)
    return min(last, now), True


# --------------------------------------------------------------------------- live
def simulate_window(city, tmy, now_utc, back_days=1):
    """Simulate (today - back_days)..tomorrow with real weather. -> ({ts_utc: zones}, quality)."""
    import esp, results, weather   # only live mode needs ESP-r
    header, tmy_days = tmy
    off = dt.timedelta(hours=city["std_offset_h"])
    today = (now_utc + off).date()
    year = today.year
    om, quality = get_weather(city)
    days = [list(d) for d in tmy_days]
    if om:
        weather.overlay(days, weather.hourly_records(om, city["std_offset_h"]), year)
    os.makedirs(WORK, exist_ok=True)
    clm = os.path.join(WORK, "climate.a")
    weather.write_climate(clm, header, days, year)
    start = max(dt.date(year, 1, 1), today - dt.timedelta(days=back_days))
    end = min(dt.date(year, 12, 31), today + dt.timedelta(days=1))
    if start.month == 2 and start.day == 29:
        start += dt.timedelta(days=1)
    cfg = esp.prepare(os.path.join(WORK, "model"), city, clm, year, start, end, 2)
    out = esp.run_bps(cfg, os.path.join(WORK, "bps.log"), timeout=120)
    sim = {ts: z for ts, z in results.read(out, start, city["std_offset_h"])}
    return sim, quality, solar.Sky(days, year, city["lat"], city["longdiff"])


simulate_window.last_weather = None


def baked_value(baked, bake_year, ts_utc, off):
    """Same local date and time in the baked typical year (29 Feb -> 28 Feb)."""
    local = ts_utc.replace(tzinfo=None) + off
    if local.month == 2 and local.day == 29:
        local -= dt.timedelta(days=1)
    try:
        key = local.replace(year=bake_year)
    except ValueError:
        key = local.replace(year=bake_year, day=28)
    if key.month == 1 and key.day == 1 and key.hour == 0 and key.minute == 0:
        key = key.replace(year=bake_year + 1)   # baked year ends at 1 Jan 00:00
    return baked.get(key)


def live(city, pub, student):
    tz = ZoneInfo(city["tz"])
    off = dt.timedelta(hours=city["std_offset_h"])
    bake_year, baked = load_baked(city["id"])
    tmy = read_tmy(city["tmy"])
    typical_sky = solar.Sky(tmy[1], bake_year, city["lat"], city["longdiff"])
    sky = typical_sky
    log = CsvLog(os.path.join(OUT, f"{student}_{city['id']}_live.csv"))
    cache, cache_quality, sim_hour, cache_age = {}, "typical_year", None, None

    now = dt.datetime.now(dt.timezone.utc)
    # first start: from the start of yesterday (local standard time), so data appears at once.
    # after a restart: carry on from the last reading sent, filling any gap (no duplicates).
    local_midnight = (now + off).replace(hour=0, minute=0, second=0, microsecond=0)
    state_path = os.path.join(OUT, f".{student}_{city['id']}_state.json")
    last_sent, resumed = load_last_sent(state_path, local_midnight - dt.timedelta(days=1) - off, now)
    first_day = (last_sent + STEP + off).date()
    back_days = max(1, ((now + off).date() - first_day).days)
    _weather_past_days[0] = max(3, back_days + 2)
    if resumed:
        print(f"[live] resuming after {last_sent:%Y-%m-%d %H:%M} UTC "
              f"({(now - last_sent).total_seconds() / 3600:.1f} h to catch up)", flush=True)

    while True:
        try:
            now = dt.datetime.now(dt.timezone.utc)
            hour = now.replace(minute=0, second=0, microsecond=0)
            if sim_hour != hour:
                try:
                    t0 = time.time()
                    cache, cache_quality, sky = simulate_window(city, tmy, now, back_days)
                    span = "yesterday" if back_days == 1 else f"{back_days} days ago"
                    sim_hour, back_days = hour, 1
                    cache_age = weather_age_h()
                    pub.weather(weather_status(cache_quality))
                    print(f"[live] simulated {span} to tomorrow in {time.time() - t0:.0f}s "
                          f"({cache_quality})", flush=True)
                except Exception as e:
                    print(f"[live] simulation failed ({e}); typical-year fallback until it recovers",
                          flush=True)
                    sim_hour = None   # retry at the next 10-minute tick

            due = []
            ts = last_sent + STEP
            while ts <= now:
                due.append(ts)
                ts += STEP
            sent, fallback = [], 0
            for ts in due:
                zones, q, step_sky, age = cache.get(ts), cache_quality, sky, cache_age
                if zones is None:
                    zones, q, step_sky, age = baked_value(baked, bake_year, ts, off), "typical_year", typical_sky, None
                    fallback += 1
                if zones is None:
                    continue
                local = ts.replace(tzinfo=None) + off
                sent.extend(publish_step(city, pub, ts, zones, tz, q, step_sky.at(local), age))
                last_sent = ts
            log.write(sent)
            if sent:
                _write_json(state_path, {"last_sent": last_sent.strftime("%Y-%m-%dT%H:%M:%SZ")})
            _write_json(os.path.join(WORK, "status.json"), {
                "updated": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "student": student, "city": city["id"],
                "last_sent": last_sent.strftime("%Y-%m-%dT%H:%M:%SZ"), "quality": cache_quality,
                "weather": weather_status(cache_quality), "csv": log.path,
                "panel": solar.pv_config(city["lat"])})
            beat()
            if due:
                print(f"[live] {now:%Y-%m-%d %H:%M} UTC: published {len(due)} step(s)"
                      f"{f', {fallback} from typical-year fallback' if fallback else ''}", flush=True)
        except KeyboardInterrupt:
            raise
        except Exception:   # never let one bad cycle end the stream
            print("[live] unexpected error, continuing:\n" + traceback.format_exc(), flush=True)

        now = dt.datetime.now(dt.timezone.utc)
        nxt = (now.replace(second=0, microsecond=0) - dt.timedelta(minutes=now.minute % 10)
               + STEP + dt.timedelta(seconds=15))
        time.sleep(max(5, (nxt - now).total_seconds()))



def start_internal_broker(port):
    """BROKER=internal (the default): run Mosquitto inside this container, so one
    'docker run -p 1883:1883 ...' is all a student needs. Returns the host to publish to."""
    import socket
    import subprocess
    conf = "/tmp/bps-mosquitto.conf"
    with open(conf, "w") as f:
        f.write(f"listener {port} 0.0.0.0\nallow_anonymous true\npersistence false\n")
    subprocess.Popen(["mosquitto", "-c", conf], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(50):
        try:
            socket.create_connection(("127.0.0.1", port), timeout=1).close()
            print(f"[mqtt] built-in broker running on port {port}", flush=True)
            return "127.0.0.1"
        except OSError:
            time.sleep(0.2)
    sys.exit("[mqtt] built-in broker did not start")

def _on_sigterm(signum, frame):
    raise KeyboardInterrupt  # 'docker stop' -> publish a clean 'stopped' status


def check_settings(student, city, mode):
    """Option B: no allocation table in the image, but stop clear mistakes early.
    A GCU student ID (s + 7 digits) in live mode must give all three panel settings."""
    import re
    names = ("PV_KWP", "PV_TILT", "PV_AZIMUTH")
    given = {n: env(n, "").strip() for n in names}
    if mode == "live" and re.fullmatch(r"s\d{7}", student) and not all(given.values()):
        missing = ", ".join(f"-e {n}=..." for n, v in given.items() if not v)
        sys.exit(f"[config] Your solar panel settings are missing ({missing}).\n"
                 f"[config] Copy all three from your allocation on GCU Learn, e.g. "
                 f"-e PV_KWP=2.9 -e PV_TILT=15 -e PV_AZIMUTH=210")
    try:
        kwp, tilt, az = (float(given[n]) if given[n] else None for n in names)
    except ValueError:
        sys.exit("[config] PV_KWP, PV_TILT and PV_AZIMUTH must be numbers, e.g. 2.9, 15 and 210")
    problems = []
    if kwp is not None and not 0.5 <= kwp <= 20:
        problems.append(f"PV_KWP={kwp} is not a sensible panel size (kWp, e.g. 2.9)")
    if tilt is not None and not 0 <= tilt <= 90:
        problems.append(f"PV_TILT={tilt} must be between 0 (flat) and 90 (upright)")
    if az is not None and not 0 <= az <= 360:
        problems.append(f"PV_AZIMUTH={az} must be a compass direction, 0-360")
    if problems:
        sys.exit("[config] " + "\n[config] ".join(problems))
    warn = []
    if kwp is not None and not 2.0 <= kwp <= 5.0:
        warn.append(f"panel size {kwp} kWp is outside the allocated range 2.0-5.0")
    if tilt is not None and not 15 <= tilt <= 45:
        warn.append(f"tilt {tilt} degrees is outside the allocated range 15-45")
    if az is not None:
        facing = 180.0 if city["lat"] >= 0 else 0.0
        if abs((az - facing + 180) % 360 - 180) > 45:
            warn.append(f"azimuth {az} faces away from the sun for {city['name']} "
                        f"(allocated panels face {facing:.0f} +/- 45)")
    for w in warn:
        print(f"[config] WARNING: {w}. Check your allocation on GCU Learn.", flush=True)


def main():
    signal.signal(signal.SIGTERM, _on_sigterm)
    city = load_city(env("CITY", required=True).strip().lower())
    student = env("STUDENT", required=True).strip().lower()
    mode = env("MODE", "replay").strip().lower()
    if mode not in ("replay", "live"):
        sys.exit("[config] MODE must be 'replay' or 'live'")
    try:
        speed = float(env("SPEED", "600"))
        assert speed > 0
    except (ValueError, AssertionError):
        sys.exit("[config] SPEED must be a positive number")
    prefix = env("TOPIC_PREFIX", "bps")
    check_settings(student, city, mode)
    beat()

    broker, port = env("BROKER", "internal").strip(), int(env("PORT", "1883"))
    if broker.lower() in ("", "internal"):
        broker = start_internal_broker(port)
    pub = Publisher(broker, port, student, prefix, env("MQTT_USER"), env("MQTT_PASS"))
    pub.connect()
    pub.meta({
        "student": student, "city": city["id"], "city_name": city["name"],
        "lat": city["lat"], "lon": city["lon"], "timezone": city["tz"],
        "model": MODEL_NAME, "zones": list(ZONES), "timestep_min": 10,
        "pv": dict(solar.pv_config(city["lat"]), zone=PV_ZONE, system_losses_pct=14),
        "mode": mode, "speed": speed if mode == "replay" else 1,
        "fields": {"air_temp": "zone air temperature, degC",
                   "heat_W": "average heating delivered during the step, W",
                   "cool_W": "average cooling delivered during the step, W",
                   "outdoor_temp": "outdoor dry-bulb, degC",
                   "solar_W_m2": "sunshine on a horizontal surface (global horizontal irradiance), W/m2",
                   "pv_W": "roof_pv only: average power from the rooftop solar array during the step, W",
                   "poa_W_m2": "roof_pv only: sunshine on the tilted panel, W/m2",
                   "local_hour": "hour of day in the city's local time",
                   "weather_age_h": "live mode: hours between the weather download and the simulation behind this reading",
                   "quality": QUALITY},
    })
    pv = solar.pv_config(city["lat"])
    print(f"[start] {mode} mode, city={city['id']}, student={student}", flush=True)
    print(f"[start] your building: {city['name']}, solar panel {pv['kWp']:g} kWp, tilt "
          f"{pv['tilt_deg']:g}, facing {pv['azimuth_deg']:g}: check this matches your allocation",
          flush=True)
    try:
        if mode == "replay":
            replay(city, pub, student, speed)
            pub.finish("finished")
        else:
            live(city, pub, student)
    except KeyboardInterrupt:
        pub.finish("stopped")


if __name__ == "__main__":
    main()
