"""BPS streamer: an ESP-r simulated building, streamed over MQTT.

MODE=replay  play back the city's baked typical year (simulated with ESP-r
             when the image was built) at SPEED simulated seconds per real
             second. No simulation runs at all, so nothing can fail here.
MODE=live    once an hour, rebuild yesterday-to-tomorrow weather from
             Open-Meteo and re-simulate with ESP-r; every 10 minutes, publish
             the steps whose time has come. Every expected step is always
             published: if the simulation fails, the baked typical-year value
             is used and labelled in the 'quality' field.
"""
import csv
import datetime as dt
import gzip
import json
import os
import signal
import sys
import time
import traceback
from zoneinfo import ZoneInfo

from mqttio import Publisher
import solar
from weather import read_tmy

APP = os.path.dirname(os.path.abspath(__file__))
BAKED = os.environ.get("BAKED_DIR", "/app/baked")
CLIMATE_DIR = os.environ.get("CLIMATE_DIR", "/app/climate")
WORK = os.environ.get("WORK_DIR", "/tmp/bps")
OUT = os.environ.get("OUT_DIR", "/out")
HEARTBEAT = os.path.join(WORK, "heartbeat")
STEP = dt.timedelta(minutes=10)
ZONES = ("office_a", "office_b", "corridor")
PV_ZONE = "roof_pv"
CSV_FIELDS = ["ts", "zone", "air_temp", "heat_W", "cool_W", "outdoor_temp",
              "solar_W_m2", "pv_W", "quality"]
OVERHEAT_C = 25.0
MODEL_NAME = "3-zone cellular office (2 offices + corridor), ESP-r"
QUALITY = {
    "ok": "simulated with real weather (live) or the typical year (replay)",
    "stale_weather": "simulated, but the weather feed was down: last good weather reused",
    "typical_weather": "simulated, but no real weather was available: typical-year weather used",
    "typical_year": "simulation unavailable: baked typical-year value for this date and time",
}


def env(name, default=None, required=False):
    v = os.environ.get(name, default)
    if required and not v:
        sys.exit(f"[config] {name} must be set")
    return v


def beat():
    try:
        os.makedirs(WORK, exist_ok=True)
        with open(HEARTBEAT, "w") as f:
            f.write(str(time.time()))
    except OSError:
        pass


def load_city(cid):
    cities = json.load(open(os.path.join(APP, "cities.json")))
    if cid not in cities:
        sys.exit(f"[config] unknown CITY '{cid}'. Valid: {', '.join(sorted(cities))}")
    c = dict(cities[cid], id=cid)
    c["tmy"] = os.path.join(CLIMATE_DIR, c["climate"] + ".a")
    return c


def load_baked(cid):
    """-> (bake_year, {local_std_datetime: {zone: row}}) in step order."""
    year = json.load(open(os.path.join(BAKED, "baked.json")))["year"]
    data = {}
    with gzip.open(os.path.join(BAKED, f"{cid}.csv.gz"), "rt", newline="") as f:
        for r in csv.DictReader(f):
            t = dt.datetime.fromisoformat(r["local"])
            data.setdefault(t, {})[r["zone"]] = {
                k: float(r[k]) for k in ("air_temp", "heat_W", "cool_W", "outdoor_temp")}
    return year, data


def message(city, zone, ts_utc, row, tz, quality, sun):
    return {
        "ts": ts_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "city": city["id"], "zone": zone,
        "air_temp": round(row["air_temp"], 2),
        "heat_W": round(row["heat_W"], 1),
        "cool_W": round(row["cool_W"], 1),
        "outdoor_temp": round(row["outdoor_temp"], 2),
        "solar_W_m2": round(sun["solar_W_m2"], 1),
        "local_hour": ts_utc.astimezone(tz).hour,
        "quality": quality,
    }


def pv_message(city, ts_utc, outdoor_temp, tz, quality, sun):
    """The rooftop solar array: a second kind of device, with its own fields."""
    return {
        "ts": ts_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "city": city["id"], "zone": PV_ZONE,
        "pv_W": round(sun["pv_W"], 1),
        "poa_W_m2": round(sun["poa_W_m2"], 1),
        "solar_W_m2": round(sun["solar_W_m2"], 1),
        "outdoor_temp": round(outdoor_temp, 2),
        "local_hour": ts_utc.astimezone(tz).hour,
        "quality": quality,
    }


def publish_step(city, pub, ts, zones, tz, quality, sun):
    """Publish one 10-minute step: three zone readings and one PV reading."""
    out = []
    for z in ZONES:
        m = message(city, z, ts, zones[z], tz, quality, sun)
        pub.reading(city["id"], z, m)
        out.append(m)
    m = pv_message(city, ts, zones[ZONES[0]]["outdoor_temp"], tz, quality, sun)
    pub.reading(city["id"], PV_ZONE, m)
    out.append(m)
    return out


class CsvLog:
    """Append-only CSV side file; never allowed to stop the stream."""
    def __init__(self, path):
        self.path = path
        self.ok = True

    def write(self, rows):
        if not self.ok:
            return
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            new = not os.path.exists(self.path)
            with open(self.path, "a", newline="") as f:
                w = csv.DictWriter(f, fieldnames=CSV_FIELDS, restval="", extrasaction="ignore")
                if new:
                    w.writeheader()
                w.writerows(rows)
        except OSError as e:
            print(f"[out] cannot write {self.path} ({e}); continuing without it", flush=True)
            self.ok = False


# --------------------------------------------------------------------------- replay
def replay(city, pub, student, speed):
    tz = ZoneInfo(city["tz"])
    off = dt.timedelta(hours=city["std_offset_h"])
    year, data = load_baked(city["id"])
    sky = solar.Sky(read_tmy(city["tmy"])[1], year, city["lat"], city["longdiff"])
    print(f"[replay] typical year for {city['name']}: {len(data)} steps, "
          f"one every {STEP.total_seconds() / speed:.3f}s", flush=True)
    path = os.path.join(OUT, f"{student}_{city['id']}_{year}.csv")
    if os.path.exists(path):
        os.remove(path)
    log = CsvLog(path)
    interval = STEP.total_seconds() / speed
    t_next = time.monotonic()
    batch = []
    for i, (local, zones) in enumerate(sorted(data.items())):
        ts = (local - off).replace(tzinfo=dt.timezone.utc)
        batch.extend(publish_step(city, pub, ts, zones, tz, "ok", sky.at(local)))
        if len(batch) >= 3000:
            log.write(batch)
            batch = []
        if i % 100 == 0:
            beat()
        if i % 1008 == 0:
            print(f"[replay] {ts:%Y-%m-%d %H:%M} UTC ({i}/{len(data)})", flush=True)
        t_next += interval
        delay = t_next - time.monotonic()
        if delay > 0:
            time.sleep(delay)
    log.write(batch)
    print("[replay] complete", flush=True)


# --------------------------------------------------------------------------- live
def simulate_window(city, tmy, now_utc):
    """Simulate yesterday..tomorrow with real weather. -> ({ts_utc: zones}, quality)."""
    import esp, results, weather   # only live mode needs ESP-r
    header, tmy_days = tmy
    off = dt.timedelta(hours=city["std_offset_h"])
    today = (now_utc + off).date()
    year = today.year
    quality = "ok"
    try:
        om = weather.fetch_open_meteo(city["lat"], city["lon"])
        simulate_window.last_weather = om
    except Exception as e:
        om = getattr(simulate_window, "last_weather", None)
        quality = "stale_weather" if om else "typical_weather"
        print(f"[weather] Open-Meteo unavailable ({e}); {quality}", flush=True)
    days = [list(d) for d in tmy_days]
    if om:
        weather.overlay(days, weather.hourly_records(om, city["std_offset_h"]), year)
    os.makedirs(WORK, exist_ok=True)
    clm = os.path.join(WORK, "climate.a")
    weather.write_climate(clm, header, days, year)
    start = max(dt.date(year, 1, 1), today - dt.timedelta(days=1))
    end = min(dt.date(year, 12, 31), today + dt.timedelta(days=1))
    if start.month == 2 and start.day == 29:
        start += dt.timedelta(days=1)
    cfg = esp.prepare(os.path.join(WORK, "model"), city, clm, year, start, end, 2)
    out = esp.run_bps(cfg, os.path.join(WORK, "bps.log"), timeout=120)
    sim = {ts: z for ts, z in results.read(out, start, city["std_offset_h"])}
    return sim, quality, solar.Sky(days, year, city["lat"], city["longdiff"])


simulate_window.last_weather = None


def baked_value(baked, bake_year, ts_utc, off):
    """Same local date and time in the baked typical year (29 Feb -> 28 Feb)."""
    local = ts_utc.replace(tzinfo=None) + off
    if local.month == 2 and local.day == 29:
        local -= dt.timedelta(days=1)
    try:
        key = local.replace(year=bake_year)
    except ValueError:
        key = local.replace(year=bake_year, day=28)
    if key.month == 1 and key.day == 1 and key.hour == 0 and key.minute == 0:
        key = key.replace(year=bake_year + 1)   # baked year ends at 1 Jan 00:00
    return baked.get(key)


def live(city, pub, student):
    tz = ZoneInfo(city["tz"])
    off = dt.timedelta(hours=city["std_offset_h"])
    bake_year, baked = load_baked(city["id"])
    tmy = read_tmy(city["tmy"])
    typical_sky = solar.Sky(tmy[1], bake_year, city["lat"], city["longdiff"])
    sky = typical_sky
    log = CsvLog(os.path.join(OUT, f"{student}_{city['id']}_live.csv"))
    cache, cache_quality, sim_hour = {}, "typical_year", None

    now = dt.datetime.now(dt.timezone.utc)
    # backlog: from the start of yesterday (local standard time), so data appears at once
    local_midnight = (now + off).replace(hour=0, minute=0, second=0, microsecond=0)
    last_sent = local_midnight - dt.timedelta(days=1) - off

    while True:
        try:
            now = dt.datetime.now(dt.timezone.utc)
            hour = now.replace(minute=0, second=0, microsecond=0)
            if sim_hour != hour:
                try:
                    t0 = time.time()
                    cache, cache_quality, sky = simulate_window(city, tmy, now)
                    sim_hour = hour
                    print(f"[live] simulated yesterday-tomorrow in {time.time() - t0:.0f}s "
                          f"({cache_quality})", flush=True)
                except Exception as e:
                    print(f"[live] simulation failed ({e}); typical-year fallback until it recovers",
                          flush=True)
                    sim_hour = None   # retry at the next 10-minute tick

            due = []
            ts = last_sent + STEP
            while ts <= now:
                due.append(ts)
                ts += STEP
            sent, fallback = [], 0
            for ts in due:
                zones, q, step_sky = cache.get(ts), cache_quality, sky
                if zones is None:
                    zones, q, step_sky = baked_value(baked, bake_year, ts, off), "typical_year", typical_sky
                    fallback += 1
                if zones is None:
                    continue
                local = ts.replace(tzinfo=None) + off
                sent.extend(publish_step(city, pub, ts, zones, tz, q, step_sky.at(local)))
                last_sent = ts
            log.write(sent)
            beat()
            if due:
                print(f"[live] {now:%Y-%m-%d %H:%M} UTC: published {len(due)} step(s)"
                      f"{f', {fallback} from typical-year fallback' if fallback else ''}", flush=True)
        except KeyboardInterrupt:
            raise
        except Exception:   # never let one bad cycle end the stream
            print("[live] unexpected error, continuing:\n" + traceback.format_exc(), flush=True)

        now = dt.datetime.now(dt.timezone.utc)
        nxt = (now.replace(second=0, microsecond=0) - dt.timedelta(minutes=now.minute % 10)
               + STEP + dt.timedelta(seconds=15))
        time.sleep(max(5, (nxt - now).total_seconds()))


def _on_sigterm(signum, frame):
    raise KeyboardInterrupt  # 'docker stop' -> publish a clean 'stopped' status


def main():
    signal.signal(signal.SIGTERM, _on_sigterm)
    city = load_city(env("CITY", required=True).strip().lower())
    student = env("STUDENT", required=True).strip().lower()
    mode = env("MODE", "replay").strip().lower()
    if mode not in ("replay", "live"):
        sys.exit("[config] MODE must be 'replay' or 'live'")
    try:
        speed = float(env("SPEED", "600"))
        assert speed > 0
    except (ValueError, AssertionError):
        sys.exit("[config] SPEED must be a positive number")
    prefix = env("TOPIC_PREFIX", "bps")
    beat()

    pub = Publisher(env("BROKER", "mosquitto"), int(env("PORT", "1883")), student,
                    prefix, env("MQTT_USER"), env("MQTT_PASS"))
    pub.connect()
    pub.meta({
        "student": student, "city": city["id"], "city_name": city["name"],
        "lat": city["lat"], "lon": city["lon"], "timezone": city["tz"],
        "model": MODEL_NAME, "zones": list(ZONES), "timestep_min": 10,
        "pv": dict(solar.pv_config(city["lat"]), zone=PV_ZONE, system_losses_pct=14),
        "mode": mode, "speed": speed if mode == "replay" else 1,
        "heating_setpoint_c": 19.0, "cooling_setpoint_c": 24.0,
        "overheat_threshold_c": OVERHEAT_C,
        "fields": {"air_temp": "zone air temperature, degC",
                   "heat_W": "average heating delivered during the step, W",
                   "cool_W": "average cooling delivered during the step, W",
                   "outdoor_temp": "outdoor dry-bulb, degC",
                   "solar_W_m2": "sunshine on a horizontal surface (global horizontal irradiance), W/m2",
                   "pv_W": "roof_pv only: average power from the rooftop solar array during the step, W",
                   "poa_W_m2": "roof_pv only: sunshine on the tilted panel, W/m2",
                   "local_hour": "hour of day in the city's local time",
                   "quality": QUALITY},
    })
    print(f"[start] {mode} mode, city={city['id']}, student={student}", flush=True)
    try:
        if mode == "replay":
            replay(city, pub, student, speed)
            pub.finish("finished")
        else:
            live(city, pub, student)
    except KeyboardInterrupt:
        pub.finish("stopped")


if __name__ == "__main__":
    main()
