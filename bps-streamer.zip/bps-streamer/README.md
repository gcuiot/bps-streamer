# BPS streamer

A building that streams its own data. The container runs a real
**ESP-r** building performance simulation of a small three-zone office in a
chosen city, at **10-minute timesteps**, and publishes the results over
**MQTT** as if the building had live sensors. Built for the GCU *Big Data and
IoT* module: students ingest it with Node-RED, store it in MongoDB and analyse
it in Metabase.

```
docker run --rm -e CITY=porto -e STUDENT=abc123 -e BROKER=<broker-host> \
           -v "$PWD/out:/out" ghcr.io/gcuiot/bps-streamer:latest
```

## Two modes

| | `MODE=replay` (default) | `MODE=live` |
|---|---|---|
| Weather | the city's typical year (bundled with ESP-r) | real weather now, from [Open-Meteo](https://open-meteo.com) (free, no API key) |
| Timestamps | simulated: 1 Jan 00:10 to 31 Dec 24:00, 2026 | real UTC time |
| Pace | `SPEED` simulated seconds per real second | one new step every 10 minutes |
| How | plays back the year **simulated when the image was built** - no simulation at run time | once an hour: rebuild yesterday-to-tomorrow weather, re-simulate (~2 s); every 10 min: publish the steps whose time has come |
| On start | starts immediately | publishes yesterday and today so far, so data appears at once |
| Ends | after the year (status `finished`) | runs until stopped |

## Built to keep running

* **Simulation happens at build time.** `docker build` simulates a typical
  year for all 13 cities and checks every result; a failure stops the build,
  never a student's stream. Replay runs no ESP-r at all.
* **Live mode never stops or skips.** Every 10-minute step is always
  published. If the weather feed is down, the simulation reuses the last good
  weather (or the typical year); if the simulation itself fails, the step is
  taken from the baked typical year for that date and time. Each reading says
  which happened in its `quality` field, and the simulation is retried every
  10 minutes until it recovers.
* **Every ESP-r run has a timeout**, one bad cycle cannot end the main loop,
  `docker stop` publishes a clean `stopped` status, and a Docker health check
  reports `unhealthy` if the streamer stops making progress.

Useful `SPEED` values: `600` = one message per zone per second (a year in about
15 h); `3600` = a year in about 2.4 h, good for a lab session; `86400` = a year
in a few minutes; `100000000` = as fast as the broker accepts.

## Settings

| Variable | Default | Meaning |
|---|---|---|
| `CITY` | required | one of the cities below |
| `STUDENT` | required | namespaces the MQTT topics |
| `MODE` | `replay` | `replay` or `live` |
| `SPEED` | `600` | replay pace, simulated seconds per real second |
| `BROKER`, `PORT` | `internal`, `1883` | MQTT broker. `internal` runs Mosquitto inside the container (publish it with `-p 1883:1883`); any other value is an external broker's host |
| `MQTT_USER`, `MQTT_PASS` | unset | broker credentials, if required |
| `TOPIC_PREFIX` | `bps` | first topic level |
| `PV_KWP` | `3.0` | rooftop array size, kWp |
| `PV_TILT` | `30` | panel tilt from horizontal, degrees |
| `PV_AZIMUTH` | facing the equator | panel direction, degrees clockwise from north |
| `WEATHER_FILE` | unset | live mode: read a saved Open-Meteo response instead of calling the API (offline demos) |

## Cities

`aberdeen`, `london`, `dublin`, `porto`, `madrid`, `berlin`, `cairo`,
`singapore`, `tokyo`, `sydney`, `phoenix`, `fairbanks`, `miami`

Typical-year weather comes from the climate files distributed with ESP-r. An
unknown `CITY` stops the container and lists the valid names.

## What it publishes

Every 10-minute step publishes four readings, QoS 1, on
`bps/<student>/<city>/<zone>/env`: one per room (`office_a`, `office_b`,
`corridor`) and one from the rooftop solar panel (`roof_pv`).

A room:

```json
{"ts": "2026-01-01T09:40:00Z", "city": "porto", "zone": "office_a",
 "air_temp": 21.3, "heat_W": 0.0, "cool_W": 412.7,
 "outdoor_temp": 11.8, "solar_W_m2": 312.4, "local_hour": 9, "quality": "ok"}
```

The solar panel (different device, different fields):

```json
{"ts": "2026-01-01T09:40:00Z", "city": "porto", "zone": "roof_pv",
 "pv_W": 905.2, "poa_W_m2": 401.7, "solar_W_m2": 312.4,
 "outdoor_temp": 11.8, "local_hour": 9, "quality": "ok"}
```

* `ts` - end of the 10-minute step, UTC.
* `heat_W`, `cool_W` - average heating/cooling delivered during the step;
  energy in kWh for the step is `W / 6000`.
* `solar_W_m2` - sunshine on a horizontal surface (global horizontal irradiance),
  from the same weather ESP-r used, so it explains the solar gains in the rooms.
* `pv_W` - average power from a 3 kWp rooftop array during the step (energy in
  kWh is `W / 6000`); `poa_W_m2` is the sunshine on the tilted panel.
* `local_hour` - hour of day in the city's own time zone, for daily patterns.
* `quality` - always present:
  `ok` (simulated with real weather, or the typical year in replay),
  `stale_weather` (weather feed down, last good weather reused),
  `typical_weather` (no real weather yet, typical-year weather used),
  `typical_year` (simulation unavailable, baked typical-year value used).

Retained metadata on `bps/<student>/meta` (city, model, zones, solar panel,
field descriptions) and retained status on
`bps/<student>/status`: `online`, then `finished` (replay done), `stopped`
(`docker stop`), or `offline` (the broker's Last Will, if the container dies).

A full replay year is 52,560 steps x 4 readings = **210,240 messages**. The same
data is written to `/out/<student>_<city>_2026.csv` (live mode appends to
`/out/<student>_<city>_live.csv`).

## The building

ESP-r's `cellular_miso` exemplar: two 3 m x 4.5 m cellular offices and a
corridor on an intermediate floor of a larger building. Only the window wall
of each office is outside; the other surfaces face similar conditioned space.
Each zone has heating and cooling (up to 1 kW each), run to a weekly schedule.
Two occupants, lighting and a computer per office. Working out how the building
is operated from its data is part of the analysis.

The same building runs in every city: only the weather changes.

## The solar panel

A rooftop array (3 kWp by default, about 15 m2, tilted 30 degrees and facing the
equator) is modelled in Python from the same hourly sunshine ESP-r is given:
sun position, isotropic sky on the tilted plane, cell temperature from NOCT,
-0.4 %/K temperature coefficient and 14 % system losses. It reports *potential*
generation; it does not feed power to the building model.

## Building the image

```
docker build -t bps-streamer .
```

The first stage compiles ESP-r from a pinned commit of
[ESP-rSource](https://github.com/ESP-rCommunity/ESP-rSource) in text mode
(no X11), with XML/CSV export (15-30 minutes); the second stage then
simulates all 13 cities inside the runtime image (about 10 minutes), which also
proves ESP-r works with the runtime's libraries. Pushing to `main` builds and
publishes `ghcr.io/<owner>/bps-streamer` (amd64) via
`.github/workflows/publish.yml`; make the package **public** in its GitHub
settings so students can pull it without logging in.

## Student lab stack

`student/` holds a ready Compose stack (Mosquitto, MongoDB, Node-RED, Metabase,
streamer), the broker config, and `bps_ingest_flow.json`, the Node-RED flow that
stores every reading in MongoDB collection `iot.bps`.

## Licence and credits

ESP-r is free software (GPL v2 or later), developed by the ESP-r community and
the Energy Systems Research Unit, University of Strathclyde. Weather in live
mode: Open-Meteo (CC BY 4.0).
