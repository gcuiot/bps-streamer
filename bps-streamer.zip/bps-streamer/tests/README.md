# Offline tests

`openmeteo_porto.json` is an Open-Meteo-format response (1-5 Nov 2026) made by
`make_fixture.py`. Run live mode without internet access:

    docker run --rm -e CITY=porto -e STUDENT=demo -e MODE=live \
      -e BROKER=<broker> -e WEATHER_FILE=/tests/openmeteo_porto.json \
      -v "$PWD/tests:/tests:ro" ghcr.io/gcu-bdiot/bps-streamer:latest

Live mode only publishes steps up to the current time, so make a fixture
covering today: `python3 make_fixture.py my.json` after editing its start date.
