"""Build an Open-Meteo-shaped response (documented schema) for offline tests."""
import datetime as dt, json, math, sys
start = (dt.datetime.fromisoformat(sys.argv[2]) if len(sys.argv) > 2
         else dt.datetime(2026, 11, 1))   # 5 days from this date, hourly, UTC
hours = 24 * 5
t = [start + dt.timedelta(hours=i) for i in range(hours)]
def solar(h):  # crude bell between 07-17 UTC
    return max(0.0, math.sin(math.pi * (h - 7) / 10)) if 7 <= h <= 17 else 0.0
data = {
 "latitude": 41.23, "longitude": -8.68, "timezone": "GMT",
 "hourly_units": {"time": "iso8601", "temperature_2m": "°C"},
 "hourly": {
  "time": [x.strftime("%Y-%m-%dT%H:%M") for x in t],
  "temperature_2m": [round(12 + 4 * math.sin(2 * math.pi * (x.hour - 9) / 24), 1) for x in t],
  "relative_humidity_2m": [80 - 10 * solar(x.hour) for x in t],
  "wind_speed_10m": [3.4 for _ in t],
  "wind_direction_10m": [250 for _ in t],
  "diffuse_radiation": [round(120 * solar(x.hour)) for x in t],
  "direct_normal_irradiance": [round(450 * solar(x.hour)) for x in t],
 }}
data["hourly"]["temperature_2m"][5] = None   # a gap, as the API sometimes returns
json.dump(data, open(sys.argv[1], "w"))
